import random

class Game:
    def __init__(self):
        self.inventory = ["Flashlight", "Camera", "Notebook", "First Aid Kit", "Rusty Knife"]
        self.health = 100
        self.evidence = 0
        self.met_hermit = False
        self.rake_health = 50
        self.solved_puzzles = []

    def start(self):
        print("Welcome to The Rake!")
        self.introduction()

    def introduction(self):
        print("You are an investigator searching for The Rake.")
        print("Your goal is to gather evidence and survive the night.")
        self.choose_action()

    def choose_action(self):
        print("\nWhere would you like to go?")
        print("1. Explore the forest")
        print("2. Go to the lake")
        print("3. Visit the old church")
        print("4. Enter the cave")
        print("5. Check inventory")
        print("6. Use first aid kit")
        print("7. Solve a puzzle")
        action = input("> ")

        if action == "1":
            self.explore_forest()
        elif action == "2":
            self.go_to_lake()
        elif action == "3":
            self.visit_church()
        elif action == "4":
            self.enter_cave()
        elif action == "5":
            self.check_inventory()
        elif action == "6":
            self.use_first_aid()
        elif action == "7":
            self.solve_puzzle()
        else:
            print("Invalid choice. Try again.")
            self.choose_action()

    def explore_forest(self):
        print("You venture into the forest...")
        encounter_chance = random.randint(1, 10)
        if encounter_chance > 7:
            self.rake_encounter()
        elif encounter_chance > 4 and not self.met_hermit:
            self.hermit_encounter()
        elif encounter_chance == 2 and "Old Key" in self.inventory:
            self.unlock_hidden_area()
        else:
            print("The forest is quiet... for now.")
        self.choose_action()

    def go_to_lake(self):
        print("You arrive at a dark, still lake. The water reflects the moonlight eerily.")
        encounter_chance = random.randint(1, 10)
        if encounter_chance > 7:
            self.rake_encounter()
        else:
            print("You find a strange, old key near the water's edge.")
            self.inventory.append("Old Key")
        self.choose_action()

    def visit_church(self):
        print("You enter the old, abandoned church. It's silent and filled with shadows.")
        encounter_chance = random.randint(1, 10)
        if encounter_chance > 7:
            self.rake_encounter()
        else:
            print("You find a dusty journal with notes about The Rake.")
            self.inventory.append("Journal")
        self.choose_action()

    def enter_cave(self):
        print("You cautiously enter the dark cave. The air is damp and cold.")
        encounter_chance = random.randint(1, 10)
        if encounter_chance > 7:
            self.rake_encounter()
        else:
            print("You find an old, rusty knife on the ground.")
            self.inventory.append("Rusty Knife")
        self.choose_action()

    def rake_encounter(self):
        print("\nYou hear rustling in the bushes...")
        print("Suddenly, The Rake leaps out at you!")
        print("1. Take a photo")
        print("2. Run away")
        print("3. Fight The Rake")
        action = input("> ")

        if action == "1":
            self.take_photo()
        elif action == "2":
            self.run_away()
        elif action == "3":
            self.fight_rake()
        else:
            print("Invalid choice. The Rake attacks you!")
            self.health -= 20
            print(f"Your health is now {self.health}.")
            if self.health <= 0:
                self.game_over()
                return
        self.choose_action()

    def take_photo(self):
        print("You quickly take a photo of The Rake.")
        self.evidence += 1
        print(f"You now have {self.evidence} pieces of evidence.")
        if self.evidence >= 5:
            print("You've gathered enough evidence! You can now attempt to escape.")
        self.choose_action()

    def run_away(self):
        print("You manage to escape, but you are injured.")
        self.health -= 10
        print(f"Your health is now {self.health}.")
        if self.health <= 0:
            self.game_over()
            return
        self.choose_action()

    def fight_rake(self):
        print("You decide to fight The Rake!")
        while self.health > 0 and self.rake_health > 0:
            print("\nChoose your action:")
            print("1. Use Rusty Knife")
            print("2. Use Flashlight")
            action = input("> ")

            if action == "1":
                self.attack_with_knife()
            elif action == "2":
                self.use_flashlight()
            else:
                print("Invalid choice. The Rake attacks you!")
                self.health -= 20

            if self.rake_health <= 0:
                print("You have defeated The Rake!")
                self.choose_action()
                return
            elif self.health <= 0:
                self.game_over()
                return

    def attack_with_knife(self):
        damage = random.randint(10, 20)
        self.rake_health -= damage
        print(f"You attack The Rake with the Rusty Knife, dealing {damage} damage.")
        print(f"The Rake's health is now {self.rake_health}.")
        self.rake_counterattack()

    def use_flashlight(self):
        print("You shine the flashlight at The Rake, momentarily blinding it.")
        self.rake_counterattack()

    def rake_counterattack(self):
        damage = random.randint(5, 15)
        self.health -= damage
        print(f"The Rake attacks you, dealing {damage} damage.")
        print(f"Your health is now {self.health}.")
        if self.health <= 0:
            self.game_over()

    def hermit_encounter(self):
        print("\nYou stumble upon a small, hidden cabin in the forest.")
        print("An old hermit steps out and looks at you with piercing eyes.")
        print("1. Talk to the hermit")
        print("2. Ignore and move on")
        action = input("> ")

        if action == "1":
            self.talk_to_hermit()
        elif action == "2":
            print("You decide to move on, leaving the hermit behind.")
        else:
            print("Invalid choice. The hermit disappears into the shadows.")
        self.choose_action()

    def talk_to_hermit(self):
        print("\nThe hermit speaks in a raspy voice:")
        print("'I've seen The Rake. It's not just a legend.'")
        print("'Take this charm. It might protect you.'")
        self.inventory.append("Protective Charm")
        self.met_hermit = True
        print("You received a Protective Charm!")
        self.choose_action()

    def unlock_hidden_area(self):
        print("\nYou use the Old Key to unlock a hidden area in the forest.")
        print("Inside, you find an old, mysterious artifact that gives you a clue about The Rake.")
        print("The artifact has strange symbols that you can't decipher without the journal.")
        self.choose_action()

    def solve_puzzle(self):
        if "Journal" in self.inventory:
            print("You use the Journal to decipher the symbols on the artifact.")
            print("The symbols reveal a hidden message about The Rake's weaknesses.")
            print("You gain valuable information that might help you in future encounters.")
            self.solved_puzzles.append("Rake's Weakness")
        else:
            print("You need the Journal to solve this puzzle. Find it first.")
        self.choose_action()

    def check_inventory(self):
        print("Inventory:", self.inventory)
        if self.health <= 30:
            print("Warning: Your health is critically low.")
        if self.evidence >= 5:
            print("You've gathered enough evidence to attempt an escape.")
        self.choose_action()

    def use_first_aid(self):
        if "First Aid Kit" in self.inventory:
            print("You use the first aid kit and heal yourself.")
            self.health = 100
            self.inventory.remove("First Aid Kit")
        else:
            print("You don't have a first aid kit.")
        self.choose_action()

    def game_over(self):
        print("\nGame Over!")
        print("You have been caught by The Rake.")
        choice = input("Would you like to restart or quit? (restart/quit) ")
        if choice.lower() == "restart":
            self.__init__()
            self.start()
        elif choice.lower() == "quit":
            print("Thanks for playing!")
        else:
            print("Invalid choice. Exiting the game.")
            print("Thanks for playing!")

game = Game()
game.start()
